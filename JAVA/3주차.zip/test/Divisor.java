package test;

import java.util.Scanner;

public class Divisor {
    public static void main(String[] args) {
//        Scanner scan = new Scanner(System.in);
//        System.out.print("양의 정수를 입력하시오 : ");
//        int n = scan.nextInt();
//        System.out.println(n + "의 약수는 다음과 같습니다.");
//
//        for(int i = 1; i <= n; ++i)
//        {
//            if(n%i == 0)
//                System.out.print(" "+i);
//        }

//        int i = 0;
//        while(i<5)
//        {
//            System.out.println("환영합니다!");
//            i++;
//        }
        Scanner sc = new Scanner(System.in);
        int month;
        do {
            System.out.print("올바른 월을 입력하시오 [1-12] : ");
            month = sc.nextInt();
        }while(month < 1 || month > 12);
        System.out.println("사용자가 입력한 월은" + month);

    }
}
