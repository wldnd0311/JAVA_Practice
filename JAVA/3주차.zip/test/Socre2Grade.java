package test;

import java.util.Scanner;

public class Socre2Grade {
    public static void main(String[] args) {
        //int score, number;
        //char grade;
        int price = 0;

        //System.out.print("성적을 입력하시오 : ");
        System.out.print("피자 종류를 입력하시오 : ");
        Scanner sc = new Scanner(System.in);
        String model = sc.next();
        //score = sc.nextInt();
        //number = score/10;

        switch (model)
        {
            //case 10:
            case "콤비네이션": price = 20000; break;
            case "슈퍼슈프림": price = 15000; break;
            case "쉬림프": price = 25000; break;
            default: price = 0; break;
        }
        System.out.println("피자: " + model + "의 가격 = " + price);
    }
}
