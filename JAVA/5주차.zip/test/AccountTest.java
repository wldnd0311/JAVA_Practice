package test;

class Account{
    private int regNumber;
    private String name;
    private int balance;

    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public int getRegNumber()
    {
        return regNumber;
    }
    public void setRegNumber(int regNumber)
    {
        this.regNumber = regNumber;
    }
    public int getBalance()
    {
        return balance;
    }
    public void setBalance(int balancee)
    {
        this.balance = balancee;
    }
}

public class AccountTest {

    public static void main(String[] args) {
        Account obj = new Account();
        obj.setName("Tom");
        obj.setBalance(100000);
        System.out.println("이름은 :"+ obj.getName()+" 통장잔고는 "+obj.getBalance()+"원 입니다.");

    }
}
