package test;


public class Dice {

    int value;

    public Dice()
    {
        value=0;
    }

    public int roll()
    {
        value=(int)(Math.random() * 6) + 1;
        return value;
    }

    public static void main(String[] args) {
        Dice dice1=new Dice();
        Dice dice2=new Dice();
        int count = 0;

        while(true)
        {
            dice1.roll();
            dice2.roll();
            System.out.println("주사위1= "+dice1.roll() +" 주사위2= "+ dice2.roll());
            count++;
            if(dice1.roll() + dice2.roll() == 2)
            {
                break;
            }
        }
        System.out.println("(1,1)이 나오는데 걸린 횟수="+count);
    }
}

