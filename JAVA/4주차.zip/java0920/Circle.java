package java0920;

public class Circle {
    public int radius;
    public String color;

    public double getArea(){
        return 3.14*radius*radius;
    }
}
