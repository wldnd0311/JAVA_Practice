package java0920;

public class Television {

    int channel;
    int volume;
    boolean onOff;

    public static void main(String[] args) {
        Television mytv = new Television();
        mytv.channel = 7;
        mytv.volume = 10;
        mytv.onOff = true;

        Television yourtv = new Television();
        yourtv.channel = 9;
        yourtv.volume = 12;
        yourtv.onOff = true;

        System.out.println("나의 TV채널은"+mytv.channel+"이고 불륨은"+mytv.volume+"입니다.");
        System.out.println("너의 TV채널은"+yourtv.channel+"이고 불륨은"+yourtv.volume+"입니다.");


    }
}
