package java0920;

import java.util.ArrayList;

public class ArrayTest1 {

    public static void main(String[] args) {

//		int [] s = new int[10];
//
//		for(int i = 0; i < s.length; i++)
//		{
//			s[i] = i;
//		}
//
//		for(int i = 0; i < s.length; i++)
//		{
//			System.out.print(s[i]);
//		}
//
//



//        int[] scores = {10,20,30,40,50};
//        for(int i = 0;i<scores.length; i++)
//            System.out.print(scores[i] + " ");






//		int [] number = {10,20,30};
//		for(int value:number)
//			System.out.print(value+" ");


//	String[] topping = {"Pepperoni","Mushroom","Onions","Sausage","Bacon"};
//
//	for(String s:topping) {
//		System.out.print(s + " ");
//	}
//


//	int  [][] seats ={{0,0,0,1,1,0,0,0,0,0},{0,0,1,1,0,0,0,0,0,0},{0,0,0,0,0,0,1,1,1,0}};
//
//	int count = 0;
//
//	for(int i = 0; i < seats.length;i++)
//	{
//		for(int k = 0; k < seats[i].length; k++)
//			count += seats[i][k];
//	}
//
//
//	System.out.print("현재 관객 수는"+count+"명입니다.");



//	int [][] ragged = new int[3][];
//	ragged[0] = new int[1];
//	ragged[1] = new int[2];
//	ragged[2] = new int[3];
//
//	for (int r = 0; r <ragged.length; r++)
//		for(int c = 0; c < ragged.length; c++)
//			ragged[r][c] = c;



        ArrayList<String> list = new ArrayList<>();
        list.add("철수");
        list.add("영희");
        list.add("순신");
        list.add("자영");
        for(String obj : list)
            System.out.print(obj + " ");



    }






}
