package test;

import java.util.ArrayList;

public class ArrayListTest
{
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<String>();
        list.add("파리");
        list.add("사이판");
        list.add("세부");
        list.add("조지아");
        list.add("하와이");
        System.out.println("여행지 추천 시스템입니다.");
        int index = (int)(Math.random() * list.size());
        System.out.println("추천여행지 : "+list.get(index));



    }
}
