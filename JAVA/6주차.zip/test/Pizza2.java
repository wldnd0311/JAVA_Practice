package test;



public class Pizza2 {
    private String topping;
    private int radius;
    static final double PI = 3.141592;
    static int count = 0;

    public Pizza2(String topping)
    {
        super();
        this.topping = topping;
        count++;
    }


}
