package test;

public class Movie
{
    String title, director;
    static int count;
    public Movie(String title, String director)
    {
        super();
        this.title = title;
        this.director = director;
        count++;
    }
}
